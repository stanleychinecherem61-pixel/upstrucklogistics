function saveShipment() {
  let trackingId = document.getElementById("trackingId").value;
  let status = document.getElementById("status").value;
  
  if (!trackingId || !status) {
    alert("Fill all fields");
    return;
  }
  
  let shipments = JSON.parse(localStorage.getItem("shipments")) || {};
  
  shipments[trackingId] = status;
  
  localStorage.setItem("shipments", JSON.stringify(shipments));
  
  alert("Shipment saved!");
  displayShipments();
}

function displayShipments() {
  let shipmentList = document.getElementById("shipmentList");
  if (!shipmentList) return;
  
  let shipments = JSON.parse(localStorage.getItem("shipments")) || {};
  shipmentList.innerHTML = "";
  
  for (let id in shipments) {
    shipmentList.innerHTML += `<p><strong>${id}</strong> - ${shipments[id]}</p>`;
  }
}

function trackParcel() {
  let trackingNumber = document.getElementById("trackingNumber").value;
  let result = document.getElementById("result");
  
  let shipments = JSON.parse(localStorage.getItem("shipments")) || {};
  
  if (shipments[trackingNumber]) {
    result.innerHTML = `<p>Status: ${shipments[trackingNumber]} ✅</p>`;
  } else {
    result.innerHTML = "<p>Tracking number not found ❌</p>";
  }
}

window.onload = displayShipments;